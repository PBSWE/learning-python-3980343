# LinkedIn Learning Python course by Joe Marini
# Example file for HelloWorld

print('Hello World')